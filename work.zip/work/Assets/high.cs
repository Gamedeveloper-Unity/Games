﻿
using UnityEngine;

public class high : MonoBehaviour
{
    public TextMesh textmesh;
    public Transform player;
    public Vector3 offset;
    public GameObject Player;
    public PlayerCollision script;
    public double score = 0;
    
    void Start()
    {
        script = Player.GetComponent<PlayerCollision>();
    }
    void Update()
    {
        score = script.highscore;
        if (score > 0)
        {
            textmesh.text = score.ToString();
        }
        else
        {
            textmesh.text = " ";
        }
        transform.position = player.position + offset;
    }
}
