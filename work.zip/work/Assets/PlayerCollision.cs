﻿using UnityEngine;

public class PlayerCollision : MonoBehaviour
{
    public Transform tf;
    public PlayerMovement movement;
    public GameObject text;
    public Rigidbody playerforce;
    public score script;
    public float delay = 9999999999999999;
    public double endscore = 0;
    public double highscore = 0;

    void Start()
    {
        script = text.GetComponent<score>();
    }

    void Update()
    {
        if (tf.position.y < -5)
        {
            movement.enabled = false;
            script.scorevalue = -1;
            Respawn();
        }
        if (Time.time >  delay)
        {
            delay = 9999999999999999;
            Respawn();
        }
        else if (delay != 9999999999999999)
        {
            script.scorevalue = -1;
        }
    }

    void OnCollisionEnter(Collision objectcollided)
    {
        if (objectcollided.collider.tag == "Obstacle")
        {
            endscore = script.scorevalue;
            if (endscore > highscore)
            {
                highscore = endscore;
            }
            script.scorevalue = -1;
            playerforce.constraints = RigidbodyConstraints.None;
            if (movement.enabled == true)
            {
                movement.enabled = false;
                delay = 3 + Time.time;
            }
        }
    }

    void Respawn()
    {
        if (movement.enabled == false)
        {
            tf.position = new Vector3(0, 0, 0);
            playerforce.velocity = new Vector3(0, 0, 0);
            movement.enabled = true;
            playerforce.constraints = RigidbodyConstraints.FreezeRotation;
            playerforce.rotation = Quaternion.Euler(0,0,0);
        }
    }
}