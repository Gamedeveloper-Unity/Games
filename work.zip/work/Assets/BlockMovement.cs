﻿using UnityEngine;

public class BlockMovement : MonoBehaviour
{

    public float x = 0.5f;

    void Start()
    {
        Vector3 newPosition = transform.position;
        newPosition.z = 300;
        transform.position = newPosition;
    }
    void Update()
    {
        Vector3 newPosition = transform.position;
        newPosition.z -= x;
        transform.position = newPosition;
    }
    void OnCollisionEnter(Collision objectcollided)
    {
        if (objectcollided.collider.name == "Player")
        {
            x = 0.25f;
        }
    }
}
