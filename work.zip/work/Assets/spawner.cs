﻿using UnityEngine;

public class spawner : MonoBehaviour
{
    public Transform[] spawnpoints;
    public GameObject obstacle;
    public GameObject otherobstacle;
    public float timebetween = 2f;
    public float timego = 0f;
    void Update ()
    {
        if (Time.time >= timego)
        {
            SpawnObstacles ();
            timego = Time.time + timebetween;
        }
    }
    void SpawnObstacles ()
    {

        int randomnumber = Random.Range(0, spawnpoints.Length);
        int choice = 0;

        for (int i = 0; i < spawnpoints.Length; i++)
        {
            choice = Random.Range(0, 2);
            if (randomnumber != i)
            {
                if (choice == 0)
                {
                    Instantiate(obstacle, spawnpoints[i].position, Quaternion.identity);
                }
                else
                {
                    Instantiate(otherobstacle, spawnpoints[i].position, Quaternion.identity);
                }                    
            }
        }
    }
}
