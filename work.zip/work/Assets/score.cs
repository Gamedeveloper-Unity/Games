﻿using UnityEngine;

public class score : MonoBehaviour
{
    public TextMesh textmesh;
    public double scorevalue = 0d;
    public float timebetween = 0f;
    private float timego = 0f;
    public Transform player;
    public Vector3 offset;
    void Update ()
    {
        transform.position = player.position + offset;
        if (Time.time >= timego)
            {
                ChangeScore ();
                timego = Time.time + timebetween;
            }
    }
    void ChangeScore ()
    {
        scorevalue++;
        textmesh.text = scorevalue.ToString();
    }
}
